/*
 * Copyright (C) 2021 - 2025 Elytrium
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package net.elytrium.limboapi.protocol.packets.s2c;

import com.velocitypowered.api.network.ProtocolVersion;
import com.velocitypowered.proxy.connection.MinecraftSessionHandler;
import com.velocitypowered.proxy.protocol.MinecraftPacket;
import com.velocitypowered.proxy.protocol.ProtocolUtils;
import io.netty.buffer.ByteBuf;

public class TimeUpdatePacket implements MinecraftPacket {

  private final long worldAge;
  private final long timeOfDay;

  public TimeUpdatePacket(long worldAge, long timeOfDay) {
    this.worldAge = worldAge;
    this.timeOfDay = timeOfDay;
  }

  public TimeUpdatePacket() {
    throw new IllegalStateException();
  }

  @Override
  public void decode(ByteBuf buf, ProtocolUtils.Direction direction, ProtocolVersion protocolVersion) {
    throw new IllegalStateException();
  }

  @Override
  public void encode(ByteBuf buf, ProtocolUtils.Direction direction, ProtocolVersion protocolVersion) {
    buf.writeLong(this.worldAge);
    if (protocolVersion.noLessThan(ProtocolVersion.MINECRAFT_26_1)) {
      ProtocolUtils.writeVarInt(buf, 1); // map size
      ProtocolUtils.writeVarInt(buf, 0); // overworld
      buf.writeLong(this.timeOfDay);
      buf.writeBoolean(false); // no ticking
    } else {
      buf.writeLong(this.timeOfDay);

      if (protocolVersion.noLessThan(ProtocolVersion.MINECRAFT_1_21_2)) {
        buf.writeBoolean(false); // no ticking
      }
    }
  }

  @Override
  public boolean handle(MinecraftSessionHandler handler) {
    return true;
  }

  @Override
  public String toString() {
    return "TimeUpdatePacket{"
        + "worldAge=" + this.worldAge
        + ", timeOfDay=" + this.timeOfDay
        + "}";
  }
}
